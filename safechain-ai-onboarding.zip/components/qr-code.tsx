"use client"

import { useEffect, useState } from "react"
import QRCode from "qrcode"

export function QrCode({ value, size = 256 }: { value: string; size?: number }) {
  const [dataUrl, setDataUrl] = useState<string>("")

  useEffect(() => {
    let active = true
    async function gen() {
      try {
        const url = await QRCode.toDataURL(value, {
          width: size,
          margin: 1,
          color: { dark: "#000000", light: "#ffffff" },
        })
        if (active) setDataUrl(url)
      } catch (e) {
        console.error("[v0] QR generation failed", e)
      }
    }
    gen()
    return () => {
      active = false
    }
  }, [value, size])

  if (!dataUrl) return <div className="h-[256px] w-[256px] bg-muted" aria-busy="true" />

  return (
    <img
      src={dataUrl || "/placeholder.svg?height=256&width=256&query=qr%20placeholder"}
      alt="Verification QR code"
      className="h-auto w-full max-w-xs rounded border"
      width={size}
      height={size}
    />
  )
}
