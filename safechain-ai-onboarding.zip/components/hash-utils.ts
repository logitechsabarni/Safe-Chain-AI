export async function sha256HexFromFile(file: File): Promise<string> {
  const buf = await file.arrayBuffer()
  return sha256HexFromArrayBuffer(buf)
}

export async function sha256HexFromArrayBuffer(buf: ArrayBuffer): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", buf)
  return bufferToHex(digest)
}

export async function sha256HexFromString(str: string): Promise<string> {
  const enc = new TextEncoder()
  const digest = await crypto.subtle.digest("SHA-256", enc.encode(str))
  return bufferToHex(digest)
}

export function bufferToHex(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf)
  const hex: string[] = []
  for (let i = 0; i < bytes.length; i++) {
    hex.push(bytes[i].toString(16).padStart(2, "0"))
  }
  return hex.join("")
}

export function randomSaltHex(bytes = 16): string {
  const arr = new Uint8Array(bytes)
  crypto.getRandomValues(arr)
  return Array.from(arr)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
}
