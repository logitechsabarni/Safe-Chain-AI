import { type NextRequest, NextResponse } from "next/server"
import { certsStore, verifyOtp } from "@/lib/store"

export async function POST(req: NextRequest) {
  const { certificateId, code } = await req.json().catch(() => ({}))
  if (!certificateId || !code) return NextResponse.json({ error: "missing_fields" }, { status: 400 })
  const rec = certsStore.get(certificateId)
  if (!rec) return NextResponse.json({ error: "not_found" }, { status: 404 })

  const res = verifyOtp(certificateId, code)
  if (!res.ok) return NextResponse.json({ ok: false, reason: res.reason }, { status: 400 })
  return NextResponse.json({ ok: true })
}
