import { type NextRequest, NextResponse } from "next/server"
import { certsStore, upsertOtp } from "@/lib/store"

function generateOtp(): string {
  // 6-digit numeric OTP
  return String(Math.floor(100000 + Math.random() * 900000))
}

export async function POST(req: NextRequest) {
  const { certificateId } = await req.json().catch(() => ({}))
  if (!certificateId) return NextResponse.json({ error: "missing_certificateId" }, { status: 400 })
  const rec = certsStore.get(certificateId)
  if (!rec) return NextResponse.json({ error: "not_found" }, { status: 404 })

  const code = generateOtp()
  // store hashed OTP with TTL 5 minutes
  upsertOtp(certificateId, code, 5 * 60_000)

  // Try Twilio SMS first (if configured and phone present)
  const sid = process.env.TWILIO_ACCOUNT_SID
  const token = process.env.TWILIO_AUTH_TOKEN
  const from = process.env.TWILIO_FROM
  const canSms = !!sid && !!token && !!from && !!rec.recipient.phone

  if (canSms) {
    try {
      const url = `https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`
      const body = new URLSearchParams({
        To: rec.recipient.phone,
        From: from!,
        Body: `Your SafeChain OTP code is ${code}. It expires in 5 minutes.`,
      })
      const auth = Buffer.from(`${sid}:${token}`).toString("base64")
      const res = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body,
      })
      if (res.ok) {
        return NextResponse.json({ ok: true, channel: "sms" })
      }
      // If Twilio fails, fall through to email or demo
    } catch {
      // swallow and fallback
    }
  }

  // Try Resend Email (if configured and email present)
  const resendKey = process.env.RESEND_API_KEY
  const fromEmail = process.env.FROM_EMAIL
  const canEmail = !!resendKey && !!fromEmail && !!rec.recipient.email

  if (canEmail) {
    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${resendKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: fromEmail,
          to: rec.recipient.email,
          subject: "Your SafeChain OTP code",
          text: `Your SafeChain OTP code is ${code}. It expires in 5 minutes.`,
        }),
      })
      if (res.ok) {
        return NextResponse.json({ ok: true, channel: "email" })
      }
      // Else fallback to demo
    } catch {
      // swallow and fallback
    }
  }

  // Demo fallback: do not send externally, return demo code to UI for prototype
  return NextResponse.json({ ok: true, demoCode: code, channel: "demo" })
}
