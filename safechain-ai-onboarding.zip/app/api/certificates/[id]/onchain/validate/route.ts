import { NextResponse } from "next/server"
import { certsStore } from "@/lib/store"
import { getProvider, normalizeSha256Hex } from "@/lib/chain"

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const id = params.id
  const rec = certsStore.get(id)
  if (!rec) return NextResponse.json({ error: "not_found" }, { status: 404 })
  if (!rec.anchor?.txHash) return NextResponse.json({ error: "not_anchored" }, { status: 400 })

  try {
    const provider = getProvider()
    const net = await provider.getNetwork()
    const tx = await provider.getTransaction(rec.anchor.txHash)
    if (!tx) return NextResponse.json({ error: "tx_not_found" }, { status: 404 })
    const receipt = await provider.getTransactionReceipt(rec.anchor.txHash)
    const block = receipt ? await provider.getBlock(receipt.blockNumber) : null

    const expected = normalizeSha256Hex(rec.fileHash)
    const input = (tx.data || "0x").toLowerCase()
    const matched = input === expected.toLowerCase()

    return NextResponse.json({
      ok: true,
      matched,
      txHash: tx.hash,
      network: `${net.name || "evm"}:${net.chainId}`,
      blockNumber: receipt?.blockNumber ?? null,
      timestamp: block?.timestamp ? Number(block.timestamp) * 1000 : null,
    })
  } catch (err: any) {
    return NextResponse.json({ error: String(err?.message || err) }, { status: 400 })
  }
}
