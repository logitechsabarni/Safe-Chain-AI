import { type NextRequest, NextResponse } from "next/server"
import { certsStore, sha256Hex } from "@/lib/store"
import { getWallet, normalizeSha256Hex } from "@/lib/chain"

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const id = params.id
  const rec = certsStore.get(id)
  if (!rec) return NextResponse.json({ error: "not_found" }, { status: 404 })

  try {
    const { network, contract } = (await req.json().catch(() => ({}))) as {
      network?: string
      contract?: string
    }

    const chosenNetwork = (network || rec.chain || "polygon").toString()

    try {
      const wallet = getWallet()
      const provider = wallet.provider!
      const net = await provider.getNetwork()
      const data = normalizeSha256Hex(rec.fileHash)
      const to = await wallet.getAddress()

      const tx = await wallet.sendTransaction({
        to,
        value: 0n,
        data, // store file SHA-256 as calldata
      })
      const receipt = await tx.wait()
      const blockNumber = receipt?.blockNumber ?? 0
      const block = blockNumber ? await provider.getBlock(blockNumber) : null
      const timestampMs = block?.timestamp ? Number(block.timestamp) * 1000 : Date.now()

      rec.anchor = {
        network: `${net.name || "evm"}:${net.chainId}`,
        txHash: tx.hash,
        blockNumber,
        timestamp: timestampMs,
        contract, // not used in this self-send tx flow
        proofType: "event",
      }
      certsStore.set(id, rec)
      return NextResponse.json({ ok: true, anchor: rec.anchor })
    } catch (e) {}

    const ts = Date.now()
    // Deterministic-looking pseudo values for prototype
    const seed = `${id}:${rec.fileHash}:${ts}:${chosenNetwork}:${contract ?? ""}`
    const txHash = "0x" + sha256Hex(seed).slice(0, 64)
    const blockNumber = Math.abs(Number.parseInt(sha256Hex(seed).slice(0, 8), 16)) % 10_000_000

    rec.anchor = {
      network: chosenNetwork,
      txHash,
      blockNumber,
      timestamp: ts,
      contract,
      proofType: "event",
    }
    certsStore.set(id, rec)

    return NextResponse.json({
      ok: true,
      anchor: rec.anchor,
    })
  } catch {
    return NextResponse.json({ error: "invalid_json" }, { status: 400 })
  }
}
