import { type NextRequest, NextResponse } from "next/server"
import { certsStore } from "@/lib/store"

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const id = params.id
  const rec = certsStore.get(id)
  if (!rec) return NextResponse.json({ error: "not_found" }, { status: 404 })
  return NextResponse.json({
    id: rec.id,
    chain: rec.chain,
    createdAt: rec.createdAt,
    status: rec.status,
    hasBio: !!rec.bio?.commitment,
    bioSalt: rec.bio?.salt || null, // do not expose in production
    anchored: !!rec.anchor,
    anchor: rec.anchor
      ? {
          network: rec.anchor.network,
          txHash: rec.anchor.txHash,
          blockNumber: rec.anchor.blockNumber,
          timestamp: rec.anchor.timestamp,
          contract: rec.anchor.contract ?? null,
          proofType: rec.anchor.proofType,
        }
      : null,
  })
}
