import { type NextRequest, NextResponse } from "next/server"
import { certsStore, newId } from "@/lib/store"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { chain, fileHash, recipient, bio } = body as {
      chain: string
      fileHash: string
      recipient: {
        name: string
        email: string
        phone: string
        idType: string
        idNumberHash: string
      }
      bio?: { commitment?: string; salt?: string }
    }

    if (
      !chain ||
      !fileHash ||
      !recipient?.name ||
      !recipient?.email ||
      !recipient?.phone ||
      !recipient?.idType ||
      !recipient?.idNumberHash
    ) {
      return NextResponse.json({ error: "missing_fields" }, { status: 400 })
    }

    const id = newId()
    const createdAt = Date.now()
    certsStore.set(id, {
      id,
      chain,
      fileHash,
      recipient,
      bio,
      createdAt,
      status: "active",
    })

    const url = `${req.nextUrl.origin}/verify/${id}?n=${encodeURIComponent(chain)}`
    return NextResponse.json({ certificateId: id, url })
  } catch {
    return NextResponse.json({ error: "invalid_json" }, { status: 400 })
  }
}
