import { type NextRequest, NextResponse } from "next/server"
import { certsStore, sha256Hex } from "@/lib/store"

export async function POST(req: NextRequest) {
  const { certificateId, idNumber } = await req.json().catch(() => ({}))
  if (!certificateId || !idNumber) return NextResponse.json({ error: "missing_fields" }, { status: 400 })
  const rec = certsStore.get(certificateId)
  if (!rec) return NextResponse.json({ error: "not_found" }, { status: 404 })

  const hash = sha256Hex(idNumber)
  const ok = hash === rec.recipient.idNumberHash
  return NextResponse.json({ ok })
}
