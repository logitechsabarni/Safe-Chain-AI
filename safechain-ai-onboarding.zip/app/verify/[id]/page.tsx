"use client"

import { useEffect, useMemo, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useSearchParams } from "next/navigation"
import { sha256HexFromArrayBuffer } from "@/components/hash-utils"

export default function VerifyPage({ params }: { params: { id: string } }) {
  const certificateId = params.id
  const sp = useSearchParams()
  const chain = sp.get("n") || "unknown"

  const [loading, setLoading] = useState(true)
  const [summary, setSummary] = useState<{
    id: string
    chain: string
    createdAt: number
    status: string
    hasBio: boolean
    bioSalt: string | null
    anchored?: boolean
    anchor?: {
      network: string
      txHash: string
      blockNumber: number
      timestamp: number
      contract: string | null
      proofType: "event" | "merkle"
    } | null
  } | null>(null)

  const [otpRequested, setOtpRequested] = useState(false)
  const [otpCode, setOtpCode] = useState("")
  const [otpOk, setOtpOk] = useState<boolean | null>(null)
  const [otpDemoCode, setOtpDemoCode] = useState<string | null>(null)

  const [idNumber, setIdNumber] = useState("")
  const [idOk, setIdOk] = useState<boolean | null>(null)

  const [thumb, setThumb] = useState<File | null>(null)
  const [bioOk, setBioOk] = useState<boolean | null>(null)

  const [onchain, setOnchain] = useState<{ loading: boolean; matched: boolean | null; error?: string }>({
    loading: false,
    matched: null,
  })

  const verdict = useMemo(() => {
    if (!summary) return null
    const baseOk = otpOk === true && idOk === true
    const bioRequiredOk = summary.hasBio ? bioOk === true : true
    if (baseOk && bioRequiredOk) return "Valid"
    if (otpOk === false || idOk === false || bioOk === false) return "Tampered or Mismatch"
    return null
  }, [summary, otpOk, idOk, bioOk])

  useEffect(() => {
    let active = true
    async function loadSummary() {
      setLoading(true)
      const res = await fetch(`/api/certificates/${certificateId}/public`)
      if (res.ok) {
        const data = await res.json()
        if (active) setSummary(data)
      } else {
        if (active) setSummary(null)
      }
      setLoading(false)
    }
    loadSummary()
    return () => {
      active = false
    }
  }, [certificateId])

  async function requestOtp() {
    const res = await fetch("/api/otp/request", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ certificateId }),
    })
    const data = await res.json()
    setOtpRequested(true)
    if (data.demoCode) setOtpDemoCode(data.demoCode)
  }

  async function verifyOtp() {
    const res = await fetch("/api/otp/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ certificateId, code: otpCode }),
    })
    setOtpOk(res.ok)
  }

  async function verifyId() {
    const res = await fetch("/api/verify/id", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ certificateId, idNumber }),
    })
    if (!res.ok) {
      setIdOk(false)
      return
    }
    const data = await res.json()
    setIdOk(data.ok === true)
  }

  async function verifyBiometric() {
    if (!thumb || !summary?.bioSalt) {
      setBioOk(false)
      return
    }
    const ab = await thumb.arrayBuffer()
    const saltBytes = saltHexToBytes(summary.bioSalt)
    const src = new Uint8Array(ab)
    const merged = new Uint8Array(saltBytes.length + src.length)
    merged.set(saltBytes, 0)
    merged.set(src, saltBytes.length)
    const commitment = await sha256HexFromArrayBuffer(merged.buffer)

    const res = await fetch("/api/biometric/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ certificateId, commitment }),
    })
    if (!res.ok) {
      setBioOk(false)
      return
    }
    const data = await res.json()
    setBioOk(data.ok === true)
  }

  async function validateOnchain() {
    if (!summary?.anchored) return
    setOnchain({ loading: true, matched: null })
    try {
      const res = await fetch(`/api/certificates/${certificateId}/onchain/validate`)
      const data = await res.json()
      if (!res.ok) {
        setOnchain({ loading: false, matched: null, error: data?.error || "validation_failed" })
        return
      }
      setOnchain({ loading: false, matched: !!data.matched })
    } catch (e: any) {
      setOnchain({ loading: false, matched: null, error: e?.message || "validation_failed" })
    }
  }

  return (
    <main className="mx-auto max-w-xl px-4 py-8">
      <header className="mb-6">
        <h1 className="text-pretty text-2xl font-semibold">Verify Certificate</h1>
        <p className="text-sm text-muted-foreground">Follow steps to verify authenticity and ownership.</p>
      </header>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>On-chain Summary</CardTitle>
          <CardDescription>Validate the anchored hash against the blockchain (if available).</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-2">
          {loading && <p>Loading...</p>}
          {!loading && !summary && <p className="text-red-600">Certificate not found.</p>}
          {!loading && summary && (
            <>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-sm text-muted-foreground">Certificate ID</div>
                <div className="text-sm font-mono">{summary.id}</div>
                <div className="text-sm text-muted-foreground">Chain</div>
                <div className="text-sm font-mono">{summary.chain || chain}</div>
                <div className="text-sm text-muted-foreground">Issued</div>
                <div className="text-sm">{new Date(summary.createdAt).toLocaleString()}</div>
                <div className="text-sm text-muted-foreground">Biometric Required</div>
                <div className="text-sm">{summary.hasBio ? "Yes" : "No"}</div>
                <div className="text-sm text-muted-foreground">Anchored</div>
                <div className="text-sm">{summary.anchored ? "Yes" : "No"}</div>
              </div>
              {summary?.anchored && summary.anchor && (
                <>
                  <div className="mt-2 grid gap-1 rounded-md border p-3">
                    <div className="text-sm">
                      Network: <span className="font-mono">{summary.anchor.network}</span>
                    </div>
                    <div className="text-sm">
                      Block: <span className="font-mono">{summary.anchor.blockNumber}</span>
                    </div>
                    <div className="text-sm">
                      Tx Hash: <span className="font-mono break-all">{summary.anchor.txHash}</span>
                    </div>
                    <div className="text-sm">Proof: {summary.anchor.proofType}</div>
                    <div className="text-sm">Time: {new Date(summary.anchor.timestamp).toLocaleString()}</div>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <Button variant="secondary" onClick={validateOnchain} disabled={onchain.loading}>
                      {onchain.loading ? "Validating..." : "Validate on-chain"}
                    </Button>
                    {onchain.matched === true && <span className="text-sm text-green-600">On-chain hash matches.</span>}
                    {onchain.matched === false && (
                      <span className="text-sm text-red-600">On-chain hash does not match.</span>
                    )}
                    {onchain.error && <span className="text-sm text-red-600">{onchain.error}</span>}
                  </div>
                </>
              )}
              {!summary?.anchored && (
                <p className="text-xs text-muted-foreground">
                  No anchor found for this certificate; on-chain validation is unavailable.
                </p>
              )}
            </>
          )}
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Step 1: OTP</CardTitle>
          <CardDescription>Request an OTP and verify to continue.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="flex items-center gap-2">
            <Button variant="secondary" onClick={requestOtp} disabled={otpRequested}>
              Request OTP
            </Button>
            {otpRequested && <span className="text-sm">OTP sent. Enter code below.</span>}
          </div>
          {otpDemoCode && <p className="text-xs text-muted-foreground">Demo code: {otpDemoCode}</p>}
          <div className="grid gap-2 md:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="otp">Enter OTP</Label>
              <Input id="otp" value={otpCode} onChange={(e) => setOtpCode(e.target.value)} placeholder="123456" />
            </div>
            <div className="flex items-end">
              <Button onClick={verifyOtp}>Verify OTP</Button>
            </div>
          </div>
          {otpOk === true && <p className="text-sm text-green-600">OTP verified.</p>}
          {otpOk === false && <p className="text-sm text-red-600">OTP failed.</p>}
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Step 2: ID Verification</CardTitle>
          <CardDescription>Enter the recipient’s ID number for hash comparison.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="grid gap-2 md:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="idNumber">ID Number</Label>
              <Input
                id="idNumber"
                value={idNumber}
                onChange={(e) => setIdNumber(e.target.value)}
                placeholder="Enter ID number"
              />
            </div>
            <div className="flex items-end">
              <Button onClick={verifyId}>Verify ID</Button>
            </div>
          </div>
          {idOk === true && <p className="text-sm text-green-600">ID verified.</p>}
          {idOk === false && <p className="text-sm text-red-600">ID mismatch.</p>}
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Step 3: Thumb Impression</CardTitle>
          <CardDescription>Upload the thumb impression if required.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="thumb">Thumb Image</Label>
            <Input
              id="thumb"
              type="file"
              accept=".png,.jpg,.jpeg,.webp"
              onChange={(e) => setThumb(e.target.files?.[0] || null)}
            />
          </div>
          <div>
            <Button onClick={verifyBiometric} disabled={!summary?.hasBio}>
              Verify Biometric
            </Button>
          </div>
          {bioOk === true && <p className="text-sm text-green-600">Biometric verified.</p>}
          {bioOk === false && summary?.hasBio && <p className="text-sm text-red-600">Biometric mismatch.</p>}
          {!summary?.hasBio && (
            <p className="text-xs text-muted-foreground">No biometric on record; this step is optional.</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Result</CardTitle>
          <CardDescription>Final assessment from the steps above.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-2">
          {!summary && (
            <p>
              Unverified: certificate not found. SafeChain AI has not performed the verification; this assessment is
              based only on the provided evidence.
            </p>
          )}
          {summary && !verdict && (
            <p>
              Unverified: steps incomplete. SafeChain AI has not performed the verification; this assessment is based
              only on the provided evidence.
            </p>
          )}
          {summary && verdict === "Valid" && (
            <p className="text-green-700">
              Valid: all required checks passed. SafeChain AI has not performed the verification; this assessment is
              based only on the provided evidence.
            </p>
          )}
          {summary && verdict === "Tampered or Mismatch" && (
            <p className="text-red-700">
              Tampered or Mismatch: one or more checks failed. SafeChain AI has not performed the verification; this
              assessment is based only on the provided evidence.
            </p>
          )}
        </CardContent>
      </Card>
    </main>
  )
}

function saltHexToBytes(hex: string): Uint8Array {
  const arr = new Uint8Array(hex.length / 2)
  for (let i = 0; i < arr.length; i++) {
    arr[i] = Number.parseInt(hex.substr(i * 2, 2), 16)
  }
  return arr
}
