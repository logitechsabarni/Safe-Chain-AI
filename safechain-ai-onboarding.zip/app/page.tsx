import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <main className="mx-auto max-w-xl px-4 py-12">
      <h1 className="mb-2 text-pretty text-3xl font-semibold">SafeChain AI Prototype</h1>
      <p className="mb-6 text-sm text-muted-foreground">
        Issue certificates with OTP, ID hash, optional thumb impression, and a verification URL + QR. Then verify by
        scanning the QR or visiting the link.
      </p>
      <div className="flex items-center gap-3">
        <Button asChild>
          <Link href="/issue">Issue a Certificate</Link>
        </Button>
      </div>
    </main>
  )
}
