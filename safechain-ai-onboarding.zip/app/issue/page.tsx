"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { QrCode } from "@/components/qr-code"
import {
  randomSaltHex,
  sha256HexFromArrayBuffer,
  sha256HexFromFile,
  sha256HexFromString,
} from "@/components/hash-utils"

type IssueResult = { certificateId: string; url: string }

export default function IssuePage() {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [idType, setIdType] = useState("National ID")
  const [idNumber, setIdNumber] = useState("")
  const [chain, setChain] = useState("polygon")
  const [file, setFile] = useState<File | null>(null)
  const [thumb, setThumb] = useState<File | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [result, setResult] = useState<IssueResult | null>(null)
  const [errors, setErrors] = useState<string | null>(null)
  const [anchorInfo, setAnchorInfo] = useState<{
    network: string
    txHash: string
    blockNumber: number
    timestamp: number
    contract?: string | null
    proofType: "event" | "merkle"
  } | null>(null)

  async function handleIssue() {
    setErrors(null)
    if (!file) {
      setErrors("Please upload the certificate file.")
      return
    }
    if (!name || !email || !phone || !idNumber) {
      setErrors("Please fill all recipient fields.")
      return
    }
    setSubmitting(true)
    try {
      const fileHash = await sha256HexFromFile(file)
      const idNumberHash = await sha256HexFromString(idNumber)

      let bio: { commitment?: string; salt?: string } | undefined = undefined
      if (thumb) {
        const salt = randomSaltHex(16)
        const ab = await thumb.arrayBuffer()
        const saltBytes = saltHexToBytes(salt)
        const src = new Uint8Array(ab)
        const merged = new Uint8Array(saltBytes.length + src.length)
        merged.set(saltBytes, 0)
        merged.set(src, saltBytes.length)
        const commitment = await sha256HexFromArrayBuffer(merged.buffer)
        bio = { commitment, salt }
      }

      const res = await fetch("/api/certificates/issue", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chain,
          fileHash,
          recipient: { name, email, phone, idType, idNumberHash },
          bio,
        }),
      })
      if (!res.ok) throw new Error("Issue failed")
      const data = (await res.json()) as IssueResult
      setResult(data)
    } catch (e: any) {
      setErrors(e.message || "Issue failed")
    } finally {
      setSubmitting(false)
    }
  }

  async function handleAnchor() {
    if (!result) return
    try {
      const res = await fetch(`/api/certificates/${result.certificateId}/anchor`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ network: chain }),
      })
      if (!res.ok) throw new Error("Anchoring failed")
      const data = await res.json()
      setAnchorInfo(data.anchor)
    } catch (e: any) {
      setErrors(e.message || "Anchoring failed")
    }
  }

  return (
    <main className="mx-auto max-w-xl px-4 py-8">
      <header className="mb-6">
        <h1 className="text-pretty text-2xl font-semibold">Issue Certificate</h1>
        <p className="text-sm text-muted-foreground">
          Create a verifiable record with OTP, ID, URL/QR, and optional thumb impression.
        </p>
      </header>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Recipient & Document</CardTitle>
          <CardDescription>Provide recipient details and upload the certificate file.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" />
          </div>
          <div className="grid gap-2 md:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="jane@example.com"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+1 555 123 4567"
              />
            </div>
          </div>
          <div className="grid gap-2 md:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="idType">ID Type</Label>
              <Input id="idType" value={idType} onChange={(e) => setIdType(e.target.value)} placeholder="National ID" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="idNumber">ID Number</Label>
              <Input
                id="idNumber"
                value={idNumber}
                onChange={(e) => setIdNumber(e.target.value)}
                placeholder="Enter ID number"
              />
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="chain">Blockchain (label only, prototype)</Label>
            <Input id="chain" value={chain} onChange={(e) => setChain(e.target.value)} placeholder="polygon" />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="file">Certificate File</Label>
            <Input
              id="file"
              type="file"
              accept=".pdf,.png,.jpg,.jpeg,.webp"
              onChange={(e) => setFile(e.target.files?.[0] || null)}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="thumb">Thumb Impression (optional image)</Label>
            <Input
              id="thumb"
              type="file"
              accept=".png,.jpg,.jpeg,.webp"
              onChange={(e) => setThumb(e.target.files?.[0] || null)}
            />
          </div>

          {errors && <p className="text-sm text-red-600">{errors}</p>}

          <Button onClick={handleIssue} disabled={submitting}>
            {submitting ? "Issuing..." : "Issue Certificate"}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader>
            <CardTitle>Verification Link & QR</CardTitle>
            <CardDescription>Share this URL or embed the QR in the certificate.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4">
            <div className="grid place-items-center">
              <QrCode value={result.url} />
            </div>
            <div className="grid gap-2">
              <Label>Verification URL</Label>
              <Input readOnly value={result.url} />
              <p className="text-xs text-muted-foreground">Scan the QR or visit the URL to verify.</p>
            </div>
            <div className="grid gap-2">
              <Label>On-chain Anchoring (prototype)</Label>
              <div className="flex items-center gap-2">
                <Button variant="secondary" onClick={handleAnchor} disabled={!!anchorInfo}>
                  {anchorInfo ? "Anchored" : "Anchor on-chain"}
                </Button>
                {anchorInfo && (
                  <span className="text-xs text-muted-foreground">
                    Anchored on {anchorInfo.network} at block {anchorInfo.blockNumber}
                  </span>
                )}
              </div>
              {anchorInfo && (
                <div className="grid gap-1 text-xs">
                  <div className="font-mono break-all">txHash: {anchorInfo.txHash}</div>
                  <div>time: {new Date(anchorInfo.timestamp).toLocaleString()}</div>
                  <div>proofType: {anchorInfo.proofType}</div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </main>
  )
}

function saltHexToBytes(hex: string): Uint8Array {
  const arr = new Uint8Array(hex.length / 2)
  for (let i = 0; i < arr.length; i++) {
    arr[i] = Number.parseInt(hex.substr(i * 2, 2), 16)
  }
  return arr
}
