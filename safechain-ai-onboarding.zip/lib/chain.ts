import { ethers } from "ethers"

// Helper to get RPC URL from env (server-only)
export function getRpcUrl() {
  const url = process.env.EVM_RPC_URL
  if (!url) throw new Error("Missing EVM_RPC_URL. Add it in Project Settings.")
  return url
}

// Helper to get private key from env (server-only)
export function getPrivateKey() {
  const pk = process.env.EVM_PRIVATE_KEY
  if (!pk) throw new Error("Missing EVM_PRIVATE_KEY. Add it in Project Settings.")
  return pk.startsWith("0x") ? pk : `0x${pk}`
}

export function getProvider() {
  return new ethers.JsonRpcProvider(getRpcUrl())
}

export function getWallet() {
  return new ethers.Wallet(getPrivateKey(), getProvider())
}

export function normalizeSha256Hex(hex: string) {
  const clean = hex.toLowerCase().replace(/^0x/, "")
  if (!/^[0-9a-f]{64}$/.test(clean)) {
    throw new Error("file hash must be a 32-byte hex string (sha-256)")
  }
  return `0x${clean}`
}
