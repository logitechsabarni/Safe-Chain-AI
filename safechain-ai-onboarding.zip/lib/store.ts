import crypto from "crypto"

export type Certificate = {
  id: string
  chain: string
  fileHash: string
  recipient: {
    name: string
    email: string
    phone: string
    idType: string
    idNumberHash: string
  }
  bio?: {
    commitment?: string
    salt?: string
  }
  createdAt: number
  status: "active" | "revoked"
  anchor?: {
    network: string
    txHash: string
    blockNumber: number
    timestamp: number
    contract?: string
    proofType: "event" | "merkle"
  }
}

type OtpRecord = {
  codeHash: string
  expiresAt: number
  attempts: number
  lockedUntil?: number
}

const g = globalThis as unknown as {
  __SAFECHAIN_CERTS__?: Map<string, Certificate>
  __SAFECHAIN_OTP__?: Map<string, OtpRecord>
}

if (!g.__SAFECHAIN_CERTS__) g.__SAFECHAIN_CERTS__ = new Map()
if (!g.__SAFECHAIN_OTP__) g.__SAFECHAIN_OTP__ = new Map()

export const certsStore = g.__SAFECHAIN_CERTS__!
export const otpStore = g.__SAFECHAIN_OTP__!

export function sha256Hex(input: string | Buffer): string {
  const h = crypto.createHash("sha256")
  h.update(input)
  return h.digest("hex")
}

export function upsertOtp(certificateId: string, code: string, ttlMs: number) {
  const now = Date.now()
  const rec: OtpRecord = {
    codeHash: sha256Hex(code),
    expiresAt: now + ttlMs,
    attempts: 0,
  }
  otpStore.set(certificateId, rec)
}

export function verifyOtp(certificateId: string, code: string): { ok: boolean; reason?: string } {
  const rec = otpStore.get(certificateId)
  const now = Date.now()
  if (!rec) return { ok: false, reason: "no_otp" }
  if (rec.lockedUntil && now < rec.lockedUntil) return { ok: false, reason: "locked" }
  if (now > rec.expiresAt) return { ok: false, reason: "expired" }

  rec.attempts += 1
  const ok = sha256Hex(code) === rec.codeHash
  if (!ok && rec.attempts >= 5) {
    rec.lockedUntil = now + 15 * 60_000
  }
  otpStore.set(certificateId, rec)
  return { ok, reason: ok ? undefined : "mismatch" }
}

export function newId() {
  // RFC4122 v4-like ID
  return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (c: any) =>
    (c ^ (crypto.randomBytes(1)[0] & (15 >> (c / 4)))).toString(16),
  )
}
